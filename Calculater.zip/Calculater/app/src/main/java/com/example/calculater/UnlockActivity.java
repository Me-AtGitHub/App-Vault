package com.example.calculater;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.andrognito.patternlockview.PatternLockView;
import com.andrognito.patternlockview.listener.PatternLockViewListener;
import com.andrognito.patternlockview.utils.PatternLockUtils;

import java.util.List;

public class UnlockActivity extends AppCompatActivity {
    SharedPreferencesHelper sharedPreferencesHelper;
    PatternLockView mPatternLockView;

    String patternMatch;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activityunlock);
        sharedPreferencesHelper = new SharedPreferencesHelper(this);

        if (sharedPreferencesHelper.getString("pattern", "").isEmpty()){
            Toast.makeText(UnlockActivity.this, "Enter Your Pattern", Toast.LENGTH_SHORT).show();
        }
        mPatternLockView = findViewById(R.id.pattern_lock_view);
        mPatternLockView.addPatternLockListener(new PatternLockViewListener() {
            @Override
            public void onStarted() {

            }

            @Override
            public void onProgress(List<PatternLockView.Dot> progressPattern) {

            }

           /* public boolean comparePatternLists(List<PatternLockView.Dot> pattern1, List<PatternLockView.Dot> pattern2) {
                if (pattern1 == null || pattern2 == null || pattern1.size() != pattern2.size()) {
                    return false; // Lists are not equal if any of them is null or have different sizes
                }

                return pattern1.equals(pattern2);
            }*/

            @Override
            public void onComplete(List<PatternLockView.Dot> pattern) {
                //Log.e("db",dbHelper.getPattern().toString());
                if (sharedPreferencesHelper.getString("pattern", "").isEmpty()) {
                    Log.e("db1",sharedPreferencesHelper.getString("pattern", ""));
                    // gat pattern to dataBase

                     if (patternMatch != null && patternMatch.equals(PatternLockUtils.patternToString(mPatternLockView, pattern))) {
                         //Log.e("patternMatch",patternMatch.toString());
                         //Log.e("EnterpattenOG" , pattern.toString());
                         // save
                         sharedPreferencesHelper.saveString("pattern", patternMatch);
                         //next screen
                         mPatternLockView.clearPattern();

                         Intent intent = new Intent(UnlockActivity.this, HomeActivity.class);
                         startActivity(intent);
                         Toast.makeText(UnlockActivity.this, "Home Successfully", Toast.LENGTH_SHORT).show();
                     }
                     else {
 //                            dbHelper.savePassword(patternMatch);
                             patternMatch = PatternLockUtils.patternToString(mPatternLockView, pattern);
                         //Log.e("Re-Enterpattern",patternMatch.toString());
                         //Log.e("Re-EnterpattenOG" , mPatternLockView.toString());
                             //Re enter password
                             mPatternLockView.clearPattern();
                             Toast.makeText(UnlockActivity.this, "Re-Enter Pattern", Toast.LENGTH_SHORT).show();
                         }

                 }else {
                    Log.e("helper","msg");
                     if (sharedPreferencesHelper.getString("pattern", "").equals(PatternLockUtils.patternToString(mPatternLockView, pattern))) {
                         Toast.makeText(UnlockActivity.this, "Successfully", Toast.LENGTH_SHORT).show();
                         Intent intent = new Intent(UnlockActivity.this, HomeActivity.class);
                         startActivity(intent);
                         finish();
                     }else {
                         Toast.makeText(UnlockActivity.this, "Wrong Password", Toast.LENGTH_SHORT).show();
                     }
                 }

            }


            @Override
            public void onCleared() {

            }
        });

    }


    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent intent = new Intent(UnlockActivity.this,MainActivity.class);
        startActivity(intent);
        finish();
    }
}