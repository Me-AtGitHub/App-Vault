package com.example.calculater;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.FileProvider;
import androidx.documentfile.provider.DocumentFile;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.FileUtils;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class FileManager extends AppCompatActivity {
    ImageView arow, idfile;
    TextView textView;
    boolean add=false;
    private List<File> selectedFilesList = new ArrayList<>();
    private RecyclerView recyclerView;
    private FileAdapter fileAdapter;
   // Destination folder path
   private Uri selectedFileUri;
    private Uri destinationFolderUri;
    String destinationFolderPath="";

    private static final int REQUEST_CODE = 1;
    private static final int MOVE_REQUEST_CODE = 2;
    private static final int PICK_REQUEST_CODE = 3;
    private static final int FILE_REQUEST_CODE = 1;
    private static final int REQUEST_FILE_CODE = 100;
    private static final int REQUEST_MOVE_FILE_CODE = 200;
    private static final int READ_STORAGE_PERMISSION_REQUEST_CODE = 41;
    private static final int WRITE_STORAGE_PERMISSION_REQUEST_CODE = 42;

    public boolean checkPermissionForReadExtertalStorage() {
        int result = getApplicationContext().checkSelfPermission(android.Manifest.permission.READ_EXTERNAL_STORAGE);
        return result == PackageManager.PERMISSION_GRANTED;
    }

    public boolean checkPermissionForWriteExternalStorage(){
        int result = getApplicationContext().checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE);
        return result == PackageManager.PERMISSION_GRANTED;
    }

    public void requestPermissionForReadExtertalStorage() {
        try {
            Log.e("permission ", "requested");
            ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.READ_EXTERNAL_STORAGE},
                    READ_STORAGE_PERMISSION_REQUEST_CODE);
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }

    public void requestPermissionForWriteExtertalStorage() {
        try {
            Log.e("permission ", "requested");
            ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.WRITE_EXTERNAL_STORAGE},
                    WRITE_STORAGE_PERMISSION_REQUEST_CODE);
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_file_manager);
        arow = findViewById(R.id.arrow);
        idfile = findViewById(R.id.fileAdd);



        // back to home button
        arow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(FileManager.this, HomeActivity.class);
                startActivity(intent);
            }
        });


        idfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (checkPermissionForReadExtertalStorage()){
                    if(checkPermissionForWriteExternalStorage()){
                        add = true;
                        Log.e("permission ", "given");
                    }else {
                        add = false;
                        Log.e("permission ", " write not given");
                        try {
                            requestPermissionForWriteExtertalStorage();
                        } catch (Exception e) {
                            throw new RuntimeException(e);
                        }
                    }
                }else {
                    add = false;
                    Log.e("permission ", "not given");
                    try {
                        requestPermissionForReadExtertalStorage();
                    } catch (Exception e) {
                        throw new RuntimeException(e);
                    }
                }
                if (add){
                 /*   Intent i = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                    startActivityForResult(i, 1);*/
                    openFileManager();
                }
                //openFileManager();
            }
        });

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        fileAdapter = new FileAdapter(selectedFilesList, this);
        recyclerView.setAdapter(fileAdapter);

    }

    private void openFileManager() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.setType("*/*"); // Set the MIME type to select any file
        //intent = Intent.createChooser(intent, "Choose a file");
        startActivityForResult(intent, FILE_REQUEST_CODE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_CODE && resultCode == RESULT_OK) {
            if (data != null) {
                selectedFileUri = data.getData();
                // Move the selected file to a folder
                Intent moveIntent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
                startActivityForResult(moveIntent, MOVE_REQUEST_CODE);
            }
        } else if (requestCode == MOVE_REQUEST_CODE && resultCode == RESULT_OK) {
            if (data != null) {
                Uri path = data.getData();
                destinationFolderUri = createFolder(path);
                // 1. content://com.android.externalstorage.documents/tree/primary%3ADocuments%2FMy%20Folder
                // 2. content://com.android.externalstorage.documents/tree/primary%3ADocuments%2FHide
                moveFileToFolder();
            }
        }
    }

   /* private void moveFileToFolder() {
        if (selectedFileUri != null && destinationFolderUri != null) {
            DocumentFile sourceFile = DocumentFile.fromSingleUri(this, selectedFileUri);
            DocumentFile destinationFolder = DocumentFile.fromTreeUri(this, destinationFolderUri);

            if (sourceFile != null && destinationFolder != null) {
                String fileName = getFileName(sourceFile.getUri().toString());
                DocumentFile newFile = destinationFolder.createFile(sourceFile.getType(), fileName);

                if (newFile != null) {
                    try {
                        String hiddenFileName = "." + newFile.getName();
                        DocumentFile hiddenFile = destinationFolder.createFile(newFile.getType(), hiddenFileName);
                        InputStream inputStream = getContentResolver().openInputStream(sourceFile.getUri());
                        OutputStream outputStream = getContentResolver().openOutputStream(newFile.getUri());

                        if (inputStream != null && outputStream != null) {

                            byte[] buffer = new byte[1024];
                            int length;

                            while ((length = inputStream.read(buffer)) > 0) {
                                outputStream.write(buffer, 0, length);
                            }
                            inputStream.close();
                            outputStream.close();
                            Toast.makeText(this, " File moved successfully", Toast.LENGTH_SHORT).show();
                            // File moved successfully

                        } if (hiddenFile != null){
                            Toast.makeText(this, " File Hide successfully", Toast.LENGTH_SHORT).show();
                        }else {
                            Toast.makeText(this, " Failed to create hidden file", Toast.LENGTH_SHORT).show();
                        }

                    } catch (IOException e) {
                        e.printStackTrace();
                        // File move failed
                    }
                } else {
                    // Failed to create new file
                }
            } else {
                // Failed to access source file or destination folder
            }
        }
    }*/

    private void moveFileToFolder() {
        if (selectedFileUri != null && destinationFolderUri != null) {
            Log.e("select file",destinationFolderUri.toString());
            DocumentFile sourceFile = DocumentFile.fromSingleUri(this, selectedFileUri);
            DocumentFile destinationFolder = DocumentFile.fromTreeUri(this, destinationFolderUri);

            Log.e("file",destinationFolder.getUri().getPath());

            if (sourceFile != null && destinationFolder != null) {
                String fileName = getFileName(sourceFile.getUri().toString());
                // Prefix the file name with a dot (.) to make it hidden
               // String hiddenFileName = "." + fileName;
                DocumentFile newFile = destinationFolder.createFile(sourceFile.getType(), fileName);

                Log.e("hiddenFileName",newFile.getUri().getPath());

                if (newFile != null) {

                    Log.e("newFile",newFile.getUri().getPath());

                    try {
                        InputStream inputStream = getContentResolver().openInputStream(sourceFile.getUri());
                        OutputStream outputStream = getContentResolver().openOutputStream(newFile.getUri());

                        if (inputStream != null && outputStream != null) {
                            byte[] buffer = new byte[1024];
                            int length;

                            while ((length = inputStream.read(buffer)) > 0) {
                                outputStream.write(buffer, 0, length);

                            }
                            inputStream.close();
                            outputStream.close();
                            //getContentResolver().delete(sourceFile.getUri(),null,null);
                            Toast.makeText(this, "File moved successfully", Toast.LENGTH_SHORT).show();
                            // File moved successfully
                        } else {
                            // Failed to open streams
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                        // File move failed
                    }
                } else {
                    // Failed to create new file
                }
            } else {
                // Failed to access source file or destination folder
            }
        }
    }

    private Uri createFolder(Uri baseDirectoryUri) {
        String folderName = ".hide"; // Specify the name for the new folder

        DocumentFile baseDirectory = DocumentFile.fromTreeUri(this, baseDirectoryUri);

        if (baseDirectory != null && baseDirectory.exists()) {
            DocumentFile hideFolder = baseDirectory.findFile(folderName);
            if (hideFolder == null) {
                hideFolder = baseDirectory.createDirectory(folderName);
            }
            if (hideFolder != null) {
                // Folder exists or created successfully
                Toast.makeText(this, "already exists", Toast.LENGTH_SHORT).show();
                return Uri.parse(baseDirectoryUri.toString() + "/" + folderName);
            } else {
                // Failed to create folder
                Toast.makeText(this, "Failed to create folder", Toast.LENGTH_SHORT).show();
                return null;
            }
        } else {
            // Base directory does not exist or is not accessible
            Toast.makeText(this, "Base directory does not exist or is not accessible", Toast.LENGTH_SHORT).show();
            return null;
        }
    }

   /* private DocumentFile findFolder(DocumentFile parentFolder, String folderName) {
        DocumentFile[] files = parentFolder.listFiles();
        if (files != null) {
            for (DocumentFile file : files) {
                if (file.isDirectory() && folderName.equals(file.getName())) {
                    return file;
                }
            }
        }
        return null;
    }*/

    private String getFileName(String filePath) {
        // Extract file name from file path
        return filePath.substring(filePath.lastIndexOf("/") + 1);
    }

    /*private boolean moveFile(String sourceFilePath, String destinationFilePath) {
        File sourceFile = new File(sourceFilePath);
        File destinationFile = new File(destinationFilePath);

        try {
            return sourceFile.renameTo(destinationFile);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }*/
    //@Override
   /* protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == FILE_REQUEST_CODE && resultCode == RESULT_OK) {
            if (data != null) {
                Uri fileUri = data.getData();
                if (fileUri != null) {
                    // Use the fileUri to work with the selected file
                    String filePath = fileUri.getPath(); // Example: "/storage/emulated/0/Documents/example.txt"
                    File file = new File(filePath);
                    Log.e("FilePath ", file.getAbsolutePath() + " " + file.getName());
                    selectedFilesList.add(file);
                    getFileNameFromUri(fileUri);
                    fileAdapter.notifyDataSetChanged();

                 //Toast.makeText(this, "Selected file: " + file.getName(), Toast.LENGTH_SHORT).show();
                }
                }
            }
        }*/
    //@SuppressLint("Range")
   /* public String getFileNameFromUri(Uri uri) {
        String fileName = null;
        if (uri.getScheme().equals("content")) {
            Cursor cursor = getContentResolver().query(uri, null, null, null, null);
            try {
                if (cursor != null && cursor.moveToFirst()) {
                    fileName = cursor.getString(cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME));
                }
            } finally {
                if (cursor != null) {
                    cursor.close();
                }
            }
        }
        if (fileName == null) {
            fileName = uri.getPath();
            int slashIndex = fileName.lastIndexOf('/');
            if (slashIndex != -1) {
                fileName = fileName.substring(slashIndex + 1);
            }
        }
        return fileName;
    }*/
}





