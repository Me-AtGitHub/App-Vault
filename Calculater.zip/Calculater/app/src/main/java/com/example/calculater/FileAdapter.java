package com.example.calculater;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.io.File;
import java.util.List;

public class FileAdapter extends RecyclerView.Adapter<FileAdapter.FileViewHolder> {

    private List<File> fileList;
    private Context context;


    public FileAdapter(List<File> fileList, Context context) {
        this.fileList = fileList;
        this.context = context;

    }

    @NonNull
    @Override
    public FileViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_file, parent, false);
        return new FileViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull FileViewHolder holder, int position) {
        File file = fileList.get(position);
        holder.textFileName.setText(file.getName());

        holder.textFileName.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                hideFile(file);
            }
        });



    }

    @Override
    public int getItemCount() {
        return fileList.size();
    }
    private void hideFile(File file) {


    }

    public class FileViewHolder extends RecyclerView.ViewHolder {

        public TextView textFileName;

        public FileViewHolder(@NonNull View itemView) {
            super(itemView);
            textFileName = itemView.findViewById(R.id.textFileName);
        }
    }

}
