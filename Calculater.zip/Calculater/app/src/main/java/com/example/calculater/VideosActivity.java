package com.example.calculater;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.ActionMode;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;


import com.andrognito.patternlockview.BuildConfig;
import com.google.android.exoplayer2.MediaItem;
import com.google.android.exoplayer2.SimpleExoPlayer;
import com.google.android.exoplayer2.ui.PlayerView;


import java.io.File;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class VideosActivity extends AppCompatActivity {
    ImageView video,arow;
    private static final int REQUEST_PICK_VIDEO = 1;

    private RecyclerView videoRecyclerView;
    private List<Uri> selectedVideoUris;
    private VideoAdapter videoAdapter;
    private ActionMode actionMode;
    private Set<Integer> selectedPositions;

    // open video player by intent

    private void openVideoPlayer(Uri fileUri) {
        String authority = BuildConfig.APPLICATION_ID + ".fileprovider";
        Uri contentUri = FileProvider.getUriForFile(this, authority, new File(fileUri.getPath()));

        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setDataAndType(contentUri, "video/*");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(intent);
    }

    private String getFilePathFromUri(Uri uri) {
        String filePath = null;
        if (uri.getScheme().equals("file")) {
            filePath = uri.getPath();
        } else if (uri.getScheme().equals("content")) {
            Cursor cursor = getContentResolver().query(uri, null, null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                int index = cursor.getColumnIndex(MediaStore.Video.Media.DATA);
                if (index != -1) {
                    filePath = cursor.getString(index);
                }
                cursor.close();
            }
        }
        return filePath;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_videos);


        video = findViewById(R.id.videoAdd);
        arow=findViewById(R.id.arrow);

        videoRecyclerView = findViewById(R.id.recyclerView);

        selectedVideoUris = new ArrayList<>();

        videoAdapter = new VideoAdapter(this, selectedVideoUris);

        videoRecyclerView.setLayoutManager(new GridLayoutManager(this, 3));

        videoRecyclerView.setAdapter(videoAdapter);

        arow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(VideosActivity.this, HomeActivity.class);
                startActivity(intent);
            }
        });

        video.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Video.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(intent, REQUEST_PICK_VIDEO);
            }
        });

     /// open video by intent methode call

     ////    on long press setOnItemClickListener
        selectedPositions = new HashSet<>();
      videoAdapter.setOnItemClickListener(new VideoAdapter.OnItemClickListener() {
          @Override
          public void onItemClick(int position) {
              if (actionMode != null){
                  toggleSelection(position);

              }else {
                  Uri videoUri = selectedVideoUris.get(position);
                  openVideoPlayer(videoUri);
              }
          }

          @Override
          public boolean onItemLongClick(int position) {
              if (actionMode == null) {
                  actionMode = startActionMode(actionModeCallback);
              }
              toggleSelection(position);
              return true;
          }
      });
    }

    private void toggleSelection(int position) {
        if (selectedPositions.contains(position)) {
            selectedPositions.remove(position);
        } else {
            selectedPositions.add(position);
        }
        videoAdapter.setSelectedPositions(selectedPositions);

        if (selectedPositions.isEmpty()) {
            actionMode.finish();
        } else {
            actionMode.invalidate();
            updateActionModeTitle();
        }

    }

    private void deleteSelectedVideos() {
        List<Uri> selectedVideos = new ArrayList<>();
        for (int position : selectedPositions) {
            selectedVideos.add(selectedVideoUris.get(position));
        }
        selectedVideoUris.removeAll(selectedVideos);
        selectedPositions.clear();
        videoAdapter.setSelectedPositions(selectedPositions);
        videoAdapter.notifyDataSetChanged();
        updateActionModeTitle();
    }

    private void updateActionModeTitle() {
        int selectedCount = selectedPositions.size();
        actionMode.setTitle(String.valueOf(selectedCount));
    }

    private ActionMode.Callback actionModeCallback = new ActionMode.Callback() {
        @Override
        public boolean onCreateActionMode(ActionMode mode, Menu menu) {
            MenuInflater inflater = mode.getMenuInflater();
            inflater.inflate(R.menu.menu, menu);
            return true;
        }

        @Override
        public boolean onPrepareActionMode(ActionMode mode, Menu menu) {
            return false;
        }

        @Override
        public boolean onActionItemClicked(ActionMode mode, MenuItem item) {
            if (item.getItemId() == R.id.actionDelete) {
                deleteSelectedVideos();
                mode.finish();
                return true;
            }
            return false;
        }

        @Override
        public void onDestroyActionMode(ActionMode mode) {
            actionMode = null;
            selectedPositions.clear();
            videoAdapter.setSelectedPositions(selectedPositions);
        }
    };

@Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
                if (requestCode == REQUEST_PICK_VIDEO && resultCode == RESULT_OK) {
                    Uri selectedVideoUri = data.getData();
                    selectedVideoUris.add(selectedVideoUri);
                    videoAdapter.notifyDataSetChanged();
            }
        }
}