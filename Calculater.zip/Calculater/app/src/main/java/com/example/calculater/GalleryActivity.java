package com.example.calculater;

import static com.example.calculater.R.id.actionDelete;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.ActionMode;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class GalleryActivity extends AppCompatActivity {
    private static final int GALLERY_REQUEST_CODE = 100;
    private List<String> mImagePaths;
    private ArrayList<String> imagePaths;
    private GridView mGridView;
    private ImageAdapter mImageAdapter;
    ImageView arro, AddImage;
    private Toolbar mToolbar;
    private ActionMode mActionMode;
    private int mSelectedCount;
    ImageView adgallery;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gallery);
        arro = findViewById(R.id.arrow);

        mGridView = findViewById(R.id.gridView);
        //mToolbar = findViewById(R.id.toolbar);
        adgallery = findViewById(R.id.galleryAdd);
        imagePaths = new ArrayList<>();
        //setSupportActionBar(mToolbar);

        mImagePaths = new ArrayList<>();
        mImageAdapter = new ImageAdapter(this,imagePaths);
        mGridView.setAdapter(mImageAdapter);


        adgallery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(intent, GALLERY_REQUEST_CODE);
            }
        });

        mGridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                    Bundle bundle = new Bundle();
                    if (imagePaths.get(position) != null){
                        Log.e("GalleryAct", imagePaths.get(position));
                        bundle.putString("imagePath", imagePaths.get(position));
                    }
                    Fragment fragment = new ImageFragment();
                    fragment.setArguments(bundle);
                    getSupportFragmentManager().beginTransaction().replace(R.id.fragmentContainer, fragment).commit();

            }
        });

        mGridView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                // Handle long press item selection
                return true;
            }
        });

        mGridView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                // Handle long press item selection
                showDeleteConfirmationDialog(position);
                return true;
            }
        });
    }
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == GALLERY_REQUEST_CODE && resultCode == RESULT_OK && data != null) {
            Uri selectedImageUri = data.getData();
            String[] projection = {MediaStore.Images.Media.DATA};
            Cursor cursor = getContentResolver().query(selectedImageUri, projection, null, null, null);
            if (cursor != null) {
                int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
                cursor.moveToFirst();
                String imagePath = cursor.getString(column_index);
                cursor.close();
                imagePaths.add(imagePath);
                mImageAdapter.notifyDataSetChanged();
            }
        }
    }

    // Method to handle deletion of selected images
    private void deleteImages(ArrayList<Integer> selectedPositions) {
        for (int i = selectedPositions.size() - 1; i >= 0; i--) {
            int position = selectedPositions.get(i);
            String imagePath = imagePaths.get(position);
            // Delete the image file using imagePath or perform desired deletion action
            File file = new File(imagePath);
            if (file.delete()) {
                imagePaths.add(imagePath);
            } else {
                // Handle deletion error, if necessary
            }
            imagePaths.remove(position);
        }

        mImageAdapter.notifyDataSetChanged();
        Toast.makeText(this, "Images deleted", Toast.LENGTH_SHORT).show();
    }
    private void showDeleteConfirmationDialog(final int position) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Delete Image");
        builder.setMessage("Are you sure you want to delete this image?");
        builder.setPositiveButton("Delete", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                ArrayList<Integer> selectedPositions = new ArrayList<>();
                selectedPositions.add(position);
                deleteImages(selectedPositions);
            }
        });
        builder.setNegativeButton("Cancel", null);
        builder.show();
    }

}